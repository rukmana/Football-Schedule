package com.jelekong.footballmatchschedule.response

data class TeamsResponse(val teams: List<Team>)