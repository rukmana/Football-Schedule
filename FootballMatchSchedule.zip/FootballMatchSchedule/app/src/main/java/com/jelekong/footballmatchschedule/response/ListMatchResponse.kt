package com.jelekong.footballmatchschedule.response

data class ListMatchResponse(val events: List<ListMatch>)

data class allMatchResponse(val event: List<ListMatch>)