package com.jelekong.footballmatchschedule.response

data class PlayersResponse(val player: List<Player>)